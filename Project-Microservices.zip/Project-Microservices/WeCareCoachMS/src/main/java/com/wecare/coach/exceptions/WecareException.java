package com.wecare.coach.exceptions;

import javax.persistence.EntityNotFoundException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class WecareException {
	@ExceptionHandler(EntityNotFoundException.class)
	public ResponseEntity<String> entitynotFoundExceptionHandler(EntityNotFoundException e)
	{
		return ResponseEntity.ok(e.getMessage());
		
	}
	
	@ExceptionHandler(AlreadyExistsException.class)
	public ResponseEntity<String> alreadyExistExceptionHandler(AlreadyExistsException e){
		return ResponseEntity.ok(e.getMessage());
	}

}
