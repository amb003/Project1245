package com.wecare.coach.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wecare.coach.dto.CoachDTO;
import com.wecare.coach.dto.LoginDTO;

import com.wecare.coach.entity.CoachEntity;

import com.wecare.coach.repository.CoachRepository;




@Service
public class CoachService {
	
	@Autowired
	CoachRepository coachRepository;
	
	public String createCoach(CoachDTO coachDTO) {
		CoachEntity coach = new CoachEntity();
		coach.setName(coachDTO.getName());
		coach.setGender(coachDTO.getGender());
		coach.setDateofBirth(coachDTO.getDateofBirth());
		coach.setPassword(coachDTO.getPassword());
		coach.setMobilenumber(coachDTO.getMobilenumber());
		coach.setSpeciality(coach.getSpeciality());
		coachRepository.save(coach);
		
		return("Successful Creation!");
	}
	

	public boolean loginCoach(LoginDTO loginDTO) throws EntityNotFoundException
	{
		
		
		Optional<CoachEntity> opt  = coachRepository.findById(loginDTO.getId());
		if(opt.isEmpty()) throw new EntityNotFoundException("Coach Not Found");
		CoachEntity coach = opt.get();
		
		Boolean isEqual = coach.getPassword().equals(loginDTO.getPassword());
		if(!isEqual) return false;
		return true;
		
		
	}
	
	public CoachDTO getCoachProfile(String coachId) throws EntityNotFoundException
	{
		
		Optional<CoachEntity> opt = coachRepository.findById(coachId) ;
		if(opt.isEmpty()) throw new EntityNotFoundException("Coach Not Found");
		
		CoachEntity coach = opt.get();
		CoachDTO coachDTO = new CoachDTO();
		 coachDTO.setCoachId(coach.getCoachId());
	     coachDTO.setName(coach.getName());
	     coachDTO.setGender(coach.getGender());
	     coachDTO.setDateofBirth(coach.getDateofBirth());
	     coachDTO.setPassword(coach.getPassword());
	     coachDTO.setMobilenumber(coach.getMobilenumber());
	     coachDTO.setSpeciality(coach.getSpeciality());
	    
		return coachDTO;
		
	}
	 

	public List<CoachDTO> showAllCoaches()
	{
		List<CoachDTO> coachDTOs = new ArrayList<CoachDTO>();
		List<CoachEntity> coaches = coachRepository.findAll();
		for(CoachEntity coach : coaches) {
		     CoachDTO coachDTO = new CoachDTO();
		     coachDTO.setCoachId(coach.getCoachId());
		     coachDTO.setName(coach.getName());
		     coachDTO.setGender(coach.getGender());
		     coachDTO.setDateofBirth(coach.getDateofBirth());
		     coachDTO.setPassword(coach.getPassword());
		     coachDTO.setMobilenumber(coach.getMobilenumber());
		     coachDTO.setSpeciality(coach.getSpeciality());
		     coachDTOs.add(coachDTO);
		     
		}
				
		return  coachDTOs;
	}
	 
	
	
}
