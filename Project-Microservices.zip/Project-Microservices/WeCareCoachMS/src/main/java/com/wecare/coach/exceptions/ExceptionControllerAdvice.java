package com.wecare.coach.exceptions;

public class ExceptionControllerAdvice {

}
