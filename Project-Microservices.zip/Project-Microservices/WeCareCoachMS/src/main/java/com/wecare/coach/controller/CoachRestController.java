package com.wecare.coach.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wecare.coach.dto.BookingDTO;
import com.wecare.coach.dto.CoachDTO;
import com.wecare.coach.dto.LoginDTO;
import com.wecare.coach.feign.util.FeignServiceUtil;
import com.wecare.coach.service.CoachService;

import org.modelmapper.internal.Errors;


@RestController
public class CoachRestController {
	@Autowired
	CoachService coachService;
	
	@Autowired
	FeignServiceUtil feignServiceUtil;
	
	@GetMapping("/coaches/all")
    public	List<CoachDTO> showAllCoaches(){
		return coachService.showAllCoaches();
		
    }
	
	@GetMapping("/coaches/{coachId}")
	public 	CoachDTO getCoachProfile(@PathVariable("coachId") String coachId ){
		return coachService.getCoachProfile(coachId);
	}
	
	@GetMapping("/coaches/booking/{coachId}")
	public List<BookingDTO> showMySchedule(@PathVariable("coachId") String coachId){
		return feignServiceUtil.findBookingByCoachId(coachId);
	}
    
	@PostMapping("/coaches")
  public ResponseEntity<String> createCoach(@RequestBody CoachDTO coachDTO, Errors error){
		String message = coachService.createCoach(coachDTO);
		  return ResponseEntity.ok(message);
	}
	
	@PostMapping("/coaches/login")
	public ResponseEntity<Boolean> loginCoach(@RequestBody LoginDTO loginDTO){
		return ResponseEntity.ok(coachService.loginCoach(loginDTO));
	}
}
