package com.wecare.coach.feign.util;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.wecare.coach.dto.BookingDTO;

@FeignClient(name="WeCareBookingMS")
public interface FeignServiceUtil {
	@GetMapping("booking/{coachID}")
	public List<BookingDTO> findBookingByCoachId(@PathVariable("coachId") String coachId);
	
}
