package com.wecare.booking.exceptions;

@SuppressWarnings("serial")
public class EntityNotFoundException extends Exception {
	public EntityNotFoundException(String message)
	{
		super(message);
	}

}
