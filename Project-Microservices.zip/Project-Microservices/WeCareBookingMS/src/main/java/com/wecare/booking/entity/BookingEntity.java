package com.wecare.booking.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bookingtable")
public class BookingEntity {
	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE)
	@Column(name="booking_id")
	private int	bookingId;
	@Column(name="user_id")
	private String	userId;
	@Column(name="appointment_date")
	private LocalDate	appointmentDate;
	@Column(name="coach_id")
	private String	coachId;
	@Column(name="slot")
	private String	slot;
	public BookingEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookingEntity(int bookingId, String userId, String coachId, String slot, LocalDate appointmentDate) {
		super();
		this.bookingId = bookingId;
		this.userId = userId;
		this.coachId = coachId;
		this.slot = slot;
		this.appointmentDate = appointmentDate;
	}
	@Override
	public String toString() {
		return "BookingEntity [bookingId=" + bookingId + ", userId=" + userId + ", coachId=" + coachId + ", slot="
				+ slot + ", appointmentDate=" + appointmentDate + "]";
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCoachId() {
		return coachId;
	}
	public void setCoachId(String coachId) {
		this.coachId = coachId;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	
}
