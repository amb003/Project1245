package com.wecare.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
@EnableFeignClients
@SpringBootApplication
public class WeCareBookingMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeCareBookingMsApplication.class, args);
	}

}
