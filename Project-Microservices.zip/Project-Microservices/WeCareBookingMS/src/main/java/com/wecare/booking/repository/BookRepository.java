package com.wecare.booking.repository;


import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.wecare.booking.entity.BookingEntity;





@Repository
public interface  BookRepository extends JpaRepository<BookingEntity,Integer>{
	
	@Query("SELECT b FROM BookingEntity b WHERE b.userId = ?1")
	List<BookingEntity> findBookingByUserId(String userId);
	
	@Query("SELECT b FROM BookingEntity b WHERE b.coachId = ?1 ")
	List<BookingEntity> findBookingByCoachId(String coachId);
	
	@Query("SELECT b FROM BookingEntity b WHERE b.userId = ?1 AND b.appointmentDate =?2 AND b.slot =?3")
    Optional<BookingEntity> findAllBookings(String userId, LocalDate appointmentDate, String slot);
	
	@Query("SELECT b FROM BookingEntity b WHERE b.bookingId = ?1")
	List<BookingEntity> findByBookingId(Integer  bookingId);
	
}