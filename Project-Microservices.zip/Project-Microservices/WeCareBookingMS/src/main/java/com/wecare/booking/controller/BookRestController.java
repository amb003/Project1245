package com.wecare.booking.controller;

import java.util.List;

//import java.time.LocalDate;
//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wecare.booking.dto.BookingDTO;
import com.wecare.booking.service.BookingService;

@RestController
public class BookRestController {
	
	@Autowired
	BookingService bookService;
	
	/*--------------------------------CoachController----------------------------------------*/
	@GetMapping("booking/{coachID}")
	public List<BookingDTO> findBookingByCoachId(@PathVariable("coachId") String coachId)
	{
		return bookService.findBookingByCoachId(coachId);
	}
	/*-----------------------------UserController--------------------------------------------*/
	@GetMapping("booking/{userID}")
	public List<BookingDTO> findBookingByUserId(@PathVariable("userId") String userId)
	{
		return bookService.findBookingByUserId(userId);
	}
	/*----------------------------------------------------------------------------------------*/
	
  @PostMapping("/users/{userId}/booking/{coachId}")
  public ResponseEntity<Boolean> bookAppointment(@PathVariable("userId") String userId,@PathVariable("coachId")  String coachId , @RequestBody BookingDTO bookingDTO){
	  
	  Boolean status = bookService.bookAppointment(userId, coachId,bookingDTO.getAppointmentDate(), bookingDTO.getSlot());
	  return ResponseEntity.ok(status);
	  } 
  @PutMapping("/booking/{bookingId}")
  public ResponseEntity<Boolean> rescheduleAppointment(@PathVariable("bookingId") Integer bookingId, @RequestBody BookingDTO bookingDTO)
  {
	  Boolean status = bookService.rescheduleAppointment(bookingId, bookingDTO.getAppointmentDate(), bookingDTO.getSlot());
	  return ResponseEntity.ok(status);
  }
  @DeleteMapping("/booking/{bookingId}")
  public ResponseEntity<Boolean> cancelAppointment(@PathVariable("bookingId") Integer bookingId)
  {
	  Boolean status = bookService.cancelAppointment(bookingId);
	  return ResponseEntity.ok(status);
  }
}
