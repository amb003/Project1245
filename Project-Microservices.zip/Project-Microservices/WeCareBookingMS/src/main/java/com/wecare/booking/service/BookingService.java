package com.wecare.booking.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import com.infosys.WeCare.utility.MailUtility;
import com.wecare.booking.dto.BookingDTO;
//import com.infosys.WeCare.dto.CoachDTO;
import com.wecare.booking.entity.BookingEntity;
import com.wecare.booking.repository.BookRepository;

@Service
public class BookingService {
	
	@Autowired
	BookRepository bookRepository;
    
	public Boolean bookAppointment(String userId, String coachId, LocalDate appointmentDate, String slot) {
		BookingEntity bookingEntity = new BookingEntity();
		bookingEntity.setUserId(userId);
		bookingEntity.setCoachId(coachId);
		bookingEntity.setSlot(slot);
		bookingEntity.setAppointmentDate(appointmentDate);
		bookRepository.save(bookingEntity);
		return true;
	}
	
	public Boolean rescheduleAppointment(Integer bookingId, LocalDate appointmentDate, String slot) {
		BookingEntity bookingEntity = bookRepository.findById(bookingId).get();
		bookingEntity.setAppointmentDate(appointmentDate);
		bookingEntity.setSlot(slot);
		bookRepository.save(bookingEntity);
		return true;
		
	}
	
	public Boolean cancelAppointment(Integer bookingId) {
		
		bookRepository.deleteById(bookingId);
		return true;
	}
	
	public 	BookingDTO findByBookingId(Integer bookingId) {
		BookingEntity bookingEntity = bookRepository.findById(bookingId).get();
		ModelMapper modelMapper = new ModelMapper();
		BookingDTO bookingDTO = new BookingDTO();
		modelMapper.map(bookingEntity, bookingDTO);
		return bookingDTO;
		
	}
	
	
	public List<BookingDTO> findBookingByCoachId(String coachId){
		List<BookingDTO> bookingDTOs = new ArrayList<BookingDTO>();
		List<BookingEntity> bookings = bookRepository.findBookingByCoachId(coachId);
		ModelMapper modelMapper = new ModelMapper();
		for(BookingEntity booking : bookings) {
			BookingDTO bookingDTO = new BookingDTO();
			modelMapper.map(booking, bookingDTO);
			bookingDTOs.add(bookingDTO);
		}
		return bookingDTOs;
		
	}
	
	public List<BookingDTO> findBookingByUserId(String userId){
		List<BookingDTO> bookingDTOs = new ArrayList<BookingDTO>();
		List<BookingEntity> bookings = bookRepository.findBookingByUserId(userId);
		ModelMapper modelMapper = new ModelMapper();
		
		for(BookingEntity booking : bookings) {
			BookingDTO bookingDTO = new BookingDTO();
			modelMapper.map(booking, bookingDTO);
			bookingDTOs.add(bookingDTO);
		}
		return bookingDTOs;
		
	}
	
	
	
	
	
	
	
	
	
	
}
