package com.wecare.booking.dto;

import java.time.LocalDate;

import javax.persistence.Column;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;


public class CoachDTO {
	
    @Column(name="coach_id")
	private String coachId;
    
    @NotEmpty
    @Size(min = 3)
    @Size(max = 50)
    @Column(name="name")
	private String name;
    
    @NotEmpty
    @Size(min = 5)
    @Size(max = 10)
    @Column(name="password")
	private String password;
    
    
    @Column(name="gender")
	private char gender;
    @Column(name="date_of_birth")
	private LocalDate dateofBirth;
    
    @NotEmpty
    @Size(min = 10)
    @Size(max = 10)
    @Column(name="mobile_number")
	private long mobilenumber;
    
    @NotEmpty
    @Size(min = 3)
    @Size(max = 50)
    @Column(name="speciality")
	private String speciality;

	@Override
	public String toString() {
		return "CoachDTO [coachId=" + coachId + ", name=" + name + ", password=" + password + ", gender=" + gender
				+ ", dateofBirth=" + dateofBirth + ", mobilenumber=" + mobilenumber + ", speciality=" + speciality
				+ "]";
	}

	public CoachDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CoachDTO(String coachId, @NotEmpty @Size(min = 3) @Size(max = 50) String name,
			@NotEmpty @Size(min = 5) @Size(max = 10) String password, char gender, LocalDate dateofBirth,
			@NotEmpty @Size(min = 10) @Size(max = 10) long mobilenumber,
			@NotEmpty @Size(min = 3) @Size(max = 50) String speciality) {
		super();
		this.coachId = coachId;
		this.name = name;
		this.password = password;
		this.gender = gender;
		this.dateofBirth = dateofBirth;
		this.mobilenumber = mobilenumber;
		this.speciality = speciality;
	}

	public String getCoachId() {
		return coachId;
	}

	public void setCoachId(String coachId) {
		this.coachId = coachId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public LocalDate getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(LocalDate dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public long getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
}
