package com.wecare.booking.dto;

public class ErrorMessage {
         private String message;

		public ErrorMessage() {
			super();
			// TODO Auto-generated constructor stub
		}

	

		public ErrorMessage(String message) {
			super();
			this.message = message;
		}



		@Override
		public String toString() {
			return "ErrorMessage [message=" + message + "]";
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}
}
