package com.wecare.booking.exceptions;

public class ExceptionControllerAdvice {

}
