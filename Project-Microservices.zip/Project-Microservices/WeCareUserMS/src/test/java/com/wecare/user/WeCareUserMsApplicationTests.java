package com.wecare.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeCareUserMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
