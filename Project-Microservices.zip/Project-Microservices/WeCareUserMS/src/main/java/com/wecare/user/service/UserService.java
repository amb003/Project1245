package com.wecare.user.service;

import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wecare.user.dto.LoginDTO;
import com.wecare.user.dto.UserDTO;

import com.wecare.user.entity.UserEntity;
import com.wecare.user.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;
     
	
	public String createUser(UserDTO userDTO) 
	{
		
		
		
		ModelMapper modelMapper = new ModelMapper();
		UserEntity user = modelMapper.map(userDTO, UserEntity.class);
		userRepository.save(user);
		return(user.getUserId());
	}
	
	
	public boolean loginUser(LoginDTO loginDTO)
	{
		
		
		Optional<UserEntity> opt  = userRepository.findById(loginDTO.getId());
		
		
		if(opt.isEmpty()) throw new EntityNotFoundException("Coach Not Found");
		UserEntity user = opt.get();
		
		Boolean isEqual = user.getPassword().equals(loginDTO.getPassword());
		if(!isEqual) return false;
		return true;
	
	}
	
	public UserDTO getUserProfile(String userId)
	{
		UserEntity user = userRepository.findById(userId).get();
		ModelMapper modelMapper = new ModelMapper();
		UserDTO userDTO = new UserDTO();
		modelMapper.map(user, userDTO);
		return userDTO;
		
	}
	
	
	
}
