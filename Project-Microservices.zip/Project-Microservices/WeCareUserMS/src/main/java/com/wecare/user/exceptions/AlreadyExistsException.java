package com.wecare.user.exceptions;

@SuppressWarnings("serial")
public class AlreadyExistsException extends Exception {
	public AlreadyExistsException( String message) {
		super(message);
	}

}
