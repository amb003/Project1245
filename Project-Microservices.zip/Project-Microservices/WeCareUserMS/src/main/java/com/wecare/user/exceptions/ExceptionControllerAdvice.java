package com.wecare.user.exceptions;

public class ExceptionControllerAdvice {

}
