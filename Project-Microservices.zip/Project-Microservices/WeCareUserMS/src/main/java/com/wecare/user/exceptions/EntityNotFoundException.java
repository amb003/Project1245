package com.wecare.user.exceptions;

@SuppressWarnings("serial")
public class EntityNotFoundException extends Exception {
	public EntityNotFoundException(String message)
	{
		super(message);
	}

}
