package com.wecare.user.feign.util;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.wecare.user.dto.BookingDTO;

@FeignClient(name="WeCareBookingMS")
public interface FeignServiceUtil {
	@GetMapping("booking/{userID}")
	public List<BookingDTO> findBookingByUserId(@PathVariable("userId") String userId);
}
