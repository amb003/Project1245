package com.wecare.user.controller;

import org.modelmapper.internal.Errors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wecare.user.dto.BookingDTO;
import com.wecare.user.dto.LoginDTO;
import com.wecare.user.dto.UserDTO;
import com.wecare.user.feign.util.FeignServiceUtil;
import com.wecare.user.service.UserService;

import java.util.List;

@RestController
public class UserRestController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	FeignServiceUtil feignServiceUtil;
	
  @PostMapping("/users")
  public ResponseEntity<String> createUser(@RequestBody UserDTO userDTO, Errors error){
	  String message = userService.createUser(userDTO);
	  return ResponseEntity.ok(message);
  }
 @PostMapping("/users/login")
  public ResponseEntity<Boolean> loginUser(@RequestBody LoginDTO loginDTO){
  return ResponseEntity.ok(userService.loginUser(loginDTO));
  }

  @GetMapping("/users/{userId}")
  public ResponseEntity<UserDTO> getUserProfile(@PathVariable("userId") String userId){
	  UserDTO user = userService.getUserProfile(userId);
	  return ResponseEntity.ok(user);
  }
     @GetMapping("/users/booking/{userId}")
     public List<BookingDTO> showMyAppointments(@PathVariable("userId") String userId){
    	 return feignServiceUtil.findBookingByUserId(userId);
     }
}
